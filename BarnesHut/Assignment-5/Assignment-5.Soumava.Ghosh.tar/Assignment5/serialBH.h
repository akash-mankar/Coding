#pragma once

void serialBarnesHut(const char*, const char*);
void readFileSerial(const char*);
void writeFileSerial(const char*);
