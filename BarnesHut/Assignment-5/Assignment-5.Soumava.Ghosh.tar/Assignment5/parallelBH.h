#pragma once

void parallelBarnesHut(const char*, const char*);
